package com.ayong.alfredyong.studytimer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    private TextView lastTimeTextView;
    private Chronometer timerTextView;
    private EditText studyTypeTextEdit;

    boolean isRunning;

    private long pauseTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        lastTimeTextView = findViewById(R.id.lastTimeTextView);
        timerTextView = findViewById(R.id.timerTextView);
        studyTypeTextEdit = findViewById(R.id.studyTypeEditText);

        pauseTime = 0;


        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        long studyTime = sharedPref.getLong("STUDY_TIME", 0);
        String studyType = sharedPref.getString("TASK_TYPE", "");


        if(studyTime == 0) {
            lastTimeTextView.setVisibility(View.INVISIBLE);
        }
        else {
            lastTimeTextView.setVisibility(View.VISIBLE);

            long second = (studyTime / 1000) % 60;
            long minute = (studyTime / (1000 * 60)) % 60;

            String time = String.format("%02d:%02d",  minute, second);

            lastTimeTextView.setText("You spent " + time + " on " + studyType + " last time.");
        }

        if(savedInstanceState != null) {
            pauseTime = savedInstanceState.getLong("PAUSE_TIME");
            isRunning = savedInstanceState.getBoolean("IS_RUNNING");
            long baseTime = savedInstanceState.getLong("BASE_TIME");


            if(pauseTime != 0) {
                timerTextView.setBase(SystemClock.elapsedRealtime() - pauseTime);
                timerTextView.stop();
            }

            if(isRunning) {
                isRunning = true;
                timerTextView.setBase(SystemClock.elapsedRealtime() - (SystemClock.elapsedRealtime() - baseTime));
                timerTextView.start();
            }
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong("PAUSE_TIME", pauseTime);
        outState.putLong("BASE_TIME", timerTextView.getBase());
        outState.putBoolean("IS_RUNNING", isRunning);

    }

    public void startTimer(View view) {
        if(studyTypeTextEdit.getText().toString().isEmpty()){
            Toast.makeText(this, "Please enter a task", Toast.LENGTH_LONG).show();
        }
        else {
            isRunning = true;
            timerTextView.setBase(SystemClock.elapsedRealtime() - pauseTime);
            timerTextView.start();
        }
    }
    public void pauseTimer(View view) {
        if(isRunning) {
            isRunning = false;
            pauseTime = SystemClock.elapsedRealtime() - timerTextView.getBase();
            timerTextView.stop();
        }
    }
    public void stopTimer(View view) {
        if(studyTypeTextEdit.getText().toString().isEmpty()){
            Toast.makeText(this, "Please enter a task", Toast.LENGTH_LONG).show();
        }
        else {
            isRunning = false;
            pauseTime = 0;

            long totalTime = SystemClock.elapsedRealtime() - timerTextView.getBase();

            if (totalTime > 0) {
                SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putLong("STUDY_TIME", totalTime);
                editor.putString("TASK_TYPE", studyTypeTextEdit.getText().toString());
                editor.apply();
            }
            timerTextView.setBase(SystemClock.elapsedRealtime());
            timerTextView.stop();
        }
    }
}
